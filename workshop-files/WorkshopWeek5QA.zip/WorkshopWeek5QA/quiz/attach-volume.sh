#!/usr/bin/env bash

. ./openrc.sh; ansible-playbook attach-volume.yaml