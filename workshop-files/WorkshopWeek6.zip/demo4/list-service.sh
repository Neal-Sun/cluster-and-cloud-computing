#!/usr/bin/env bash

echo "docker-machine ssh manager docker service ls"

docker-machine ssh manager docker service ls
