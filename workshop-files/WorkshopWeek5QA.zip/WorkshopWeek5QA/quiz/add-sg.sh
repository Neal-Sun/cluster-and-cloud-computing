#!/usr/bin/env bash

. ./openrc.sh; ansible-playbook add-sg.yaml