#!/usr/bin/env bash

. ./openrc.sh; ansible-playbook --vault-id @prompt q7_vault.yaml