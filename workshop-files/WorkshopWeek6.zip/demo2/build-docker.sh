#!/bin/bash

echo "docker build -t demo2 ."

docker build -t demo2 .