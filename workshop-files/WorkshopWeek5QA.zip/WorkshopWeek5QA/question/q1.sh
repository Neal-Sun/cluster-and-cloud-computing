#!/usr/bin/env bash

. ./openrc.sh; ansible-playbook q1.yaml