#!/usr/bin/env bash

echo "docker-machine ssh manager docker service ps nginx"

docker-machine ssh manager docker service ps nginx
