#!/usr/bin/env bash

. ./openrc.sh; ansible-playbook q8.yaml